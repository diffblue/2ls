int main() {
  int x=0,i=0;
  //for(i=0;i<10;i++)
  if(i<10) {
    x=x+i;
    i++;
  }
  if(i<10) {
    x=x+i;        
    i++;
  }
  if(i<10) {
    x=x+i;        
    i++;
  }
  assert(x>10);
}

