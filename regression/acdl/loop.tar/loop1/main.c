int main() {
  int x=0,i;
  for(i=0;i<10;i++)
    x = x+i;
  assert(x>10);
}

